const api = globalThis.browser ?? globalThis.chrome;
const SITE_NOTES_PORTS = new Set(["4200"]);

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "GET_OPEN_TABS") {
    return;
  }

  api.tabs
    .query({})
    .then((tabs) => {
      const openTabs = tabs
        .filter(isUsefulTab)
        .sort(compareTabs)
        .map((tab) => ({
          id: tab.id,
          windowId: tab.windowId,
          title: cleanTitle(tab.title || ""),
          url: tab.url,
          favIconUrl: tab.favIconUrl || "",
          active: Boolean(tab.active),
        }));

      sendResponse({ tabs: openTabs });
    })
    .catch((error) => {
      sendResponse({ tabs: [], error: String(error) });
    });

  return true;
});

function isUsefulTab(tab) {
  if (!tab.url) {
    return false;
  }

  try {
    const url = new URL(tab.url);
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      return false;
    }

    const isLocalhost = url.hostname === "localhost" || url.hostname === "127.0.0.1";
    if (isLocalhost && SITE_NOTES_PORTS.has(url.port || "80")) {
      return false;
    }

    return true;
  } catch {
    return false;
  }
}

function compareTabs(a, b) {
  if (a.active !== b.active) {
    return a.active ? -1 : 1;
  }

  return (b.lastAccessed || 0) - (a.lastAccessed || 0);
}

function cleanTitle(title) {
  return title.replace(/\s+-\s+YouTube$/i, "").trim();
}
