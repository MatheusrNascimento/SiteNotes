const api = globalThis.browser ?? globalThis.chrome;
const SOURCE_APP = "sitenotes-app";
const SOURCE_EXT = "sitenotes-extension";

window.addEventListener("message", (event) => {
  if (event.source !== window || !event.data || event.data.source !== SOURCE_APP) {
    return;
  }

  const { type, requestId } = event.data;

  if (type === "PING") {
    window.postMessage({ source: SOURCE_EXT, type: "PONG", requestId }, "*");
    return;
  }

  if (type === "GET_OPEN_TABS") {
    sendRuntimeMessage({ type: "GET_OPEN_TABS" })
      .then((response) => {
        window.postMessage(
          {
            source: SOURCE_EXT,
            type: "OPEN_TABS",
            requestId,
            tabs: response?.tabs || [],
            error: response?.error || null,
          },
          "*"
        );
      })
      .catch((error) => {
        window.postMessage(
          {
            source: SOURCE_EXT,
            type: "OPEN_TABS",
            requestId,
            tabs: [],
            error: error?.message || String(error),
          },
          "*"
        );
      });
  }
});

window.postMessage({ source: SOURCE_EXT, type: "READY" }, "*");

function sendRuntimeMessage(message) {
  const result = api.runtime.sendMessage(message);
  if (result && typeof result.then === "function") {
    return result;
  }

  return new Promise((resolve, reject) => {
    api.runtime.sendMessage(message, (response) => {
      const err = api.runtime.lastError;
      if (err) {
        reject(new Error(err.message));
        return;
      }

      resolve(response);
    });
  });
}
